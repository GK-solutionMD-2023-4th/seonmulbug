import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '계좌번호 입력하기',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final FocusNode _accountNumberFocusNode = FocusNode();

  void _showBankListModal(BuildContext context) {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          height: 300,
          child: Column(
            children: [
              // First row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildSquareContainer('국민은행'),
                  _buildSquareContainer('대구은행'),
                  _buildSquareContainer('신한은행'),
                  _buildSquareContainer('기업은행'),
                ],
              ),
              // Second row
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildSquareContainer('농협은행'),
                  _buildSquareContainer('부산은행'),
                  _buildSquareContainer('카카오뱅크'),
                  _buildSquareContainer('토스뱅크'),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSquareContainer(String bankName) {
    return Container(
      width: 80, // Adjust the width as needed
      height: 80, // Adjust the height as needed
      margin: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.blue, // Add your preferred color
        borderRadius: BorderRadius.circular(10),
      ),
      child: Center(
        child: Text(
          bankName,
          style: TextStyle(
            color: Colors.white,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus(); // Close the keyboard when tapped outside of a text field
      },
      child: Scaffold(
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Title
              Padding(
                padding: const EdgeInsets.only(left: 20.0), // Adjust the left padding
                child: Text(
                  '계좌번호 입력하기',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              SizedBox(height: 20), // Add some space between the title and text fields
              // 계좌번호 입력 텍스트 필드
              Container(
                width: MediaQuery.of(context).size.width * 0.85, // Slightly wider
                height: 80, // Taller
                margin: EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20), // Make corners more rounded
                  border: Border.all(color: Colors.black), // Add black border
                  color: Colors.white,
                ),
                child: TextField(
                  focusNode: _accountNumberFocusNode,
                  keyboardType: TextInputType.number, // Set numeric keyboard
                  decoration: InputDecoration(
                    labelText: '계좌번호',
                    border: InputBorder.none,
                    contentPadding: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  ),
                  onTap: () {
                    FocusScope.of(context).requestFocus(_accountNumberFocusNode);
                  },
                ),
              ),
              // 은행/증권사 컨테이너
              Container(
                width: MediaQuery.of(context).size.width * 0.85, // Slightly wider
                height: 80, // Taller
                margin: EdgeInsets.all(10),
                padding: EdgeInsets.only(left: 20), // Add left padding
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20), // Make corners more rounded
                  border: Border.all(color: Colors.black), // Add black border
                  color: Colors.white,
                ),
                child: GestureDetector(
                  onTap: () {
                    _showBankListModal(context);
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '은행/증권사',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w300, // Set a lighter font weight
                        ),
                      ),
                      // Add a triangle icon with left padding
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Icon(
                          Icons.arrow_forward_ios,
                          size: 16,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}